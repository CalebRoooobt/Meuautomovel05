package atividade2;

public class PopulacaoDeBaratas {
    private long populacao;
    public PopulacaoDeBaratas(long populacao){
        this.populacao = populacao;
    }
}
